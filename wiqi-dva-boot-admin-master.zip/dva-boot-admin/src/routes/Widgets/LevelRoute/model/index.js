import modelEnhance from '@/utils/modelEnhance';

export default modelEnhance({
  namespace: 'level1',
});