import modelEnhance from '@/utils/modelEnhance';

export default modelEnhance({
  namespace: 'blank',
});