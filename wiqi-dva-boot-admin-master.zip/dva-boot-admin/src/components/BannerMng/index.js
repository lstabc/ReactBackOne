import BannerMng from './BannerMng';

export default BannerMng;