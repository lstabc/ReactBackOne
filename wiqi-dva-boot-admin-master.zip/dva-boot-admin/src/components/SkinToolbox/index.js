import SkinToolbox from './SkinToolbox';

export default SkinToolbox;