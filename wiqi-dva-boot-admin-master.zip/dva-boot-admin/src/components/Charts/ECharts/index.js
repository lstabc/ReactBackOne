// 引入全部echarts包,若想按需加载则直接引EC.js
import 'echarts';
import EC, { echarts } from './EC';

export { echarts };
export default EC;
