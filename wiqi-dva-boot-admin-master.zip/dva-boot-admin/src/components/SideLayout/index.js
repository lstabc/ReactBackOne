import SideLayout from './SideLayout';

export default SideLayout;