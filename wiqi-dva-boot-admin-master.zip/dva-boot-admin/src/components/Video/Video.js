import React, { Component } from 'react';
import './style/index.less';

/**
 * 视频播放组件
 */
class Video extends Component {
  static defaultProps = {
    prefixCls: 'antui-video'
  };

  render() {
    return (
      <div>
        
      </div>
    );
  }
}

export default Video;