import LeftSideBar from './LeftSideBar';
import RightSideBar from './RightSideBar';

export default {
  LeftSideBar,
  RightSideBar
}

export {
  LeftSideBar,
  RightSideBar
}