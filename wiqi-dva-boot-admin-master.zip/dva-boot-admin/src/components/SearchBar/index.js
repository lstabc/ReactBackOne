import SearchBar from './SearchBar';

export default SearchBar;