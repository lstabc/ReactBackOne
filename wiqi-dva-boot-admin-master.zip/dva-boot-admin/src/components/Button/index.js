import Button from './Button';
import Ripple from './Ripple';

Button.Ripple = Ripple;
export default Button;