import LazyLoad from './LazyLoad';

export default LazyLoad;