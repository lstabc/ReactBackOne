import ModalForm from './ModalForm';
import ModalTable from './ModalTable';

export {
  ModalForm,
  ModalTable
}