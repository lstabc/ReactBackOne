import Print from './Print';

export default Print;