import Panel from './Panel';

export default Panel;