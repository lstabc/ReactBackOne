import DataTable, { Tip, Oper, Paging } from './DataTable';
import { Editable, EditableOper } from './Editable';
export { Tip, Oper, Paging, Editable, EditableOper };
export default DataTable;
