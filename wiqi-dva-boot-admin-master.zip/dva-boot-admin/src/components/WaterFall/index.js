import WaterFall from './WaterFall';

export default WaterFall;